﻿namespace PaintingEstimate
{
    partial class PaintingEstimate
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lengthLabel = new Label();
            widthLabel = new Label();
            lengthInput = new TextBox();
            widthInput = new TextBox();
            calcButton = new Button();
            costOutput = new Label();
            SuspendLayout();
            // 
            // lengthLabel
            // 
            lengthLabel.AutoSize = true;
            lengthLabel.Location = new Point(49, 49);
            lengthLabel.Name = "lengthLabel";
            lengthLabel.Size = new Size(172, 20);
            lengthLabel.TabIndex = 0;
            lengthLabel.Text = "Enter length of the room";
            // 
            // widthLabel
            // 
            widthLabel.AutoSize = true;
            widthLabel.Location = new Point(49, 90);
            widthLabel.Name = "widthLabel";
            widthLabel.Size = new Size(167, 20);
            widthLabel.TabIndex = 1;
            widthLabel.Text = "Enter width of the room";
            // 
            // lengthInput
            // 
            lengthInput.Location = new Point(246, 46);
            lengthInput.Name = "lengthInput";
            lengthInput.Size = new Size(125, 27);
            lengthInput.TabIndex = 2;
            // 
            // widthInput
            // 
            widthInput.Location = new Point(246, 87);
            widthInput.Name = "widthInput";
            widthInput.Size = new Size(125, 27);
            widthInput.TabIndex = 3;
            // 
            // calcButton
            // 
            calcButton.Location = new Point(49, 146);
            calcButton.Name = "calcButton";
            calcButton.Size = new Size(131, 29);
            calcButton.TabIndex = 4;
            calcButton.Text = "Calculate Cost";
            calcButton.UseVisualStyleBackColor = true;
            calcButton.Click += CalcButton_Click;
            // 
            // costOutput
            // 
            costOutput.BorderStyle = BorderStyle.Fixed3D;
            costOutput.Location = new Point(246, 150);
            costOutput.Name = "costOutput";
            costOutput.Size = new Size(125, 25);
            costOutput.TabIndex = 5;
            // 
            // PaintingEstimate
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(425, 233);
            Controls.Add(costOutput);
            Controls.Add(calcButton);
            Controls.Add(widthInput);
            Controls.Add(lengthInput);
            Controls.Add(widthLabel);
            Controls.Add(lengthLabel);
            Name = "PaintingEstimate";
            Text = "Painting Estimate";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lengthLabel;
        private Label widthLabel;
        private TextBox lengthInput;
        private TextBox widthInput;
        private Button calcButton;
        private Label costOutput;
    }
}
