namespace PaintingEstimate
{
    public partial class PaintingEstimate : Form
    {
        public PaintingEstimate()
        {
            InitializeComponent();
        }

        private void CalcButton_Click(object sender, EventArgs e)
        {
            int length = Convert.ToInt32(lengthInput.Text);
            int width = Convert.ToInt32(widthInput.Text);
            costOutput.Text = Main(length, width).ToString("C");
        }
        private int Main(int length, int width)
        {
            int lengthArea, widthArea, fullArea, cost;
            lengthArea = length * 18;
            widthArea = width * 18;
            fullArea = lengthArea + widthArea;
            cost = fullArea * 6;
            return cost;
        }
    }
}
